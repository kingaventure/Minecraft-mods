
package net.mcreator.firstmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BizzaruimoreItem extends Item {
	public BizzaruimoreItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
