
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.firstmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.firstmod.item.SpotifypremiumItem;
import net.mcreator.firstmod.item.RareuimoreItem;
import net.mcreator.firstmod.item.RareuimingotItem;
import net.mcreator.firstmod.item.RareuimdiskItem;
import net.mcreator.firstmod.item.RareuimbowItem;
import net.mcreator.firstmod.item.BizzaruimoreItem;
import net.mcreator.firstmod.FirstModMod;

public class FirstModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FirstModMod.MODID);
	public static final RegistryObject<Item> RAREUIM = block(FirstModModBlocks.RAREUIM);
	public static final RegistryObject<Item> RAREUIMORE = REGISTRY.register("rareuimore", () -> new RareuimoreItem());
	public static final RegistryObject<Item> RAREUIMINGOT = REGISTRY.register("rareuimingot", () -> new RareuimingotItem());
	public static final RegistryObject<Item> RAREUIMDISK = REGISTRY.register("rareuimdisk", () -> new RareuimdiskItem());
	public static final RegistryObject<Item> RAREUIMBOW = REGISTRY.register("rareuimbow", () -> new RareuimbowItem());
	public static final RegistryObject<Item> SPOTIFYPREMIUM = REGISTRY.register("spotifypremium", () -> new SpotifypremiumItem());
	public static final RegistryObject<Item> BIZZARUIMORE = REGISTRY.register("bizzaruimore", () -> new BizzaruimoreItem());
	public static final RegistryObject<Item> BIZZARUIMOREBLOCK = block(FirstModModBlocks.BIZZARUIMOREBLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
