
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.firstmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.firstmod.FirstModMod;

public class FirstModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FirstModMod.MODID);
	public static final RegistryObject<CreativeModeTab> JULIENFOLIE = REGISTRY.register("julienfolie",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.first_mod.julienfolie")).icon(() -> new ItemStack(FirstModModItems.RAREUIMORE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FirstModModItems.RAREUIMORE.get());
				tabData.accept(FirstModModBlocks.RAREUIM.get().asItem());
				tabData.accept(FirstModModItems.RAREUIMINGOT.get());
				tabData.accept(FirstModModItems.RAREUIMDISK.get());
				tabData.accept(FirstModModItems.RAREUIMBOW.get());
				tabData.accept(FirstModModItems.SPOTIFYPREMIUM.get());
				tabData.accept(FirstModModItems.BIZZARUIMORE.get());
				tabData.accept(FirstModModBlocks.BIZZARUIMOREBLOCK.get().asItem());
			}).withSearchBar().build());
}
