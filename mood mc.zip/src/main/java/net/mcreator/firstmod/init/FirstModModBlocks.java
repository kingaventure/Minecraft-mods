
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.firstmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.firstmod.block.RareuimBlock;
import net.mcreator.firstmod.FirstModMod;

public class FirstModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FirstModMod.MODID);
	public static final RegistryObject<Block> RAREUIM = REGISTRY.register("rareuim", () -> new RareuimBlock());
	public static final RegistryObject<Block> BIZZARUIMOREBLOCK = REGISTRY.register("bizzaruimoreblock", () -> new BizzaruimoreblockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
